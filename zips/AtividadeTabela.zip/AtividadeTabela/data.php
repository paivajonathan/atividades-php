<?php

$pratos = [
  [
    "descricao" => "Lasanha a quatro queijos",
    "preco" => "12,60",
  ],
  [
    "descricao" => "Frango ao molho madeira",
    "preco" => "10,00",
  ],
  [
    "descricao" => "Arroz à grega",
    "preco" => "9,40",
  ],
  [
    "descricao" => "Feijoada à moda da casa",
    "preco" => "11,20",
  ],
  [
    "descricao" => "Nhoque paulista",
    "preco" => "08,50",
  ],
  [
    "descricao" => "Bacalhau ao forno",
    "preco" => "15,20",
  ],
  [
    "descricao" => "Feijão branco",
    "preco" => "10,00",
  ],
];

$diaAtual = date("w");