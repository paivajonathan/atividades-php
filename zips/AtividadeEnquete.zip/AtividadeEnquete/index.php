<?php

session_start();

function aumentarVotos($candidato)
{
    if (!isset($_SESSION[$candidato]))
    {
        $_SESSION[$candidato] = 0;
    }
    
    $_SESSION[$candidato]++;
}

function obterPorcentagem($candidato)
{
    try
    {
        $votosCandidato = $_SESSION[$candidato] ?? 0;
        $votosTotais = ($_SESSION["darth"] ?? 0) + ($_SESSION["homer"] ?? 0) + ($_SESSION["branco"] ?? 0) + ($_SESSION["nulo"] ?? 0); 
        echo "" . round((($votosCandidato / $votosTotais) * 100), 2) . "%";
    }
    catch (DivisionByZeroError $e)
    {
        echo "0%";
    }
}

function atualizarPagina()
{
    header("Location: " . $_SERVER["PHP_SELF"]);
}

if (isset($_POST["candidato"]))
{
    $candidato = $_POST["candidato"];

    switch ($candidato)
    {
        case "darth":
            aumentarVotos("darth");
            break;
        case "homer":
            aumentarVotos("homer");
            break;
        case "branco":
            aumentarVotos("branco");
            break;
        case "nulo":
            aumentarVotos("nulo");
            break;
    }

    atualizarPagina();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Votação - IFPI</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
        }

        img {
            width: 100px;
        }

        fieldset#candidatos {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        fieldset#candidatos div {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 1rem;
        }

        div#botoes {
            display: flex;
            justify-content: space-evenly;
            margin: 1rem 0;
        }

        div#botoes button {
            padding: .5rem 2rem;
        }

        fieldset#resultados {
            text-align: left;
        }

        fieldset#resultados hr {
            margin-left: 0;
            border-radius: 5px;
        }

        fieldset#resultados hr#darth {
            border: 5px solid blue;
        }

        fieldset#resultados hr#homer {
            border: 5px solid red;
        }

        fieldset#resultados hr#branco {
            border: 5px solid #eee;
        }

        fieldset#resultados hr#nulo {
            border: 5px solid #aaa;
        }
    </style>
</head>
<body>
    <h1>Sistema de Votação - IFPI</h1>
    <h3>Qual candidato você escolhe para presidente do Grêmio Estudantil?</h3>
    <fieldset id="candidatos">
        <div>
            <img src="./darth.jpg" alt="Darth Vader">
            <span><strong>Darth Vader</strong> - Candidato 01</span> 
        </div>
        <div>
            <img src="./homer.png" alt="Homer Simpson">
            <span><strong>Homer Simpson</strong> - Candidato 02</span> 
        </div>
    </fieldset>
    <form method="post">
        <div id="botoes">
            <button name="candidato" value="darth">Darth Vader</button>
            <button name="candidato" value="homer">Homer Simpson</button>
            <button name="candidato" value="branco">Branco</button>
            <button name="candidato" value="nulo">Nulo</button>
        </div>
    </form>
    <fieldset id="resultados">
        <legend>Resultado Parcial</legend>
        <p>
            Candidato 01 - <?php obterPorcentagem("darth"); ?>
            <hr id="darth" width="<?php obterPorcentagem("darth"); ?>">
            Candidato 02 - <?php obterPorcentagem("homer"); ?>
            <hr id="homer" width="<?php obterPorcentagem("homer"); ?>">
            Branco - <?php obterPorcentagem("branco"); ?>
            <hr id="branco" width="<?php obterPorcentagem("branco"); ?>">
            Nulo - <?php obterPorcentagem("nulo"); ?>
            <hr id="nulo" width="<?php obterPorcentagem("nulo"); ?>">
        </p>
    </fieldset>
</body>
</html>